
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'rauhaanrizvi',
  applicationName: 'gamereviews-serverless',
  appUid: 'Pxw4fXcSBpjBtBq5yy',
  orgUid: '4050183a-d53e-4d9b-bff3-50286d5d7902',
  deploymentUid: '4e3de633-b95a-4c67-8eb1-e31c64acfca2',
  serviceName: 'gamereviews-serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'gamereviews-serverless-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}